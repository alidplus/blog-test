const { Service } = require('feathers-mongoose');

exports.Likes = class Likes extends Service {
  
};
